# Flask Skeleton

`source ./.venv/bin/activate` for venc activation
`python3 ./root.py` to run

- Has Tailwind
- Has daisyUI
- Has routing
